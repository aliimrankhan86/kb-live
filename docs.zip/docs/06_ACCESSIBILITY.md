# Accessibility Standards

This file is intentionally a pointer.

The canonical accessibility standards are maintained in: `docs/ACCESSIBILITY.md`

Do not add accessibility rules here. Update `docs/ACCESSIBILITY.md` instead.
