# Security Standards

This file is intentionally a pointer.

The canonical security standards are maintained in: `docs/SECURITY.md`

Do not add security rules here. Update `docs/SECURITY.md` instead.
