# Model Routing

## Routing Rules

- Gemini 3 Pro: architecture, planning, micro-task specs only.
- Codex: implementation, tests, small diffs, audit updates.
